#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Structure for customer details
struct Customer {
    string name;
    string contact;
    string selectedPackage;
};

// Class for tourism management
class TourismManagement {
private:
    vector<string> tourPackages;
    vector<Customer> customers;

public:
    TourismManagement() {
        // Adding some predefined tour packages
        tourPackages.push_back("Beach Paradise - 3 Days ($300)");
        tourPackages.push_back("Mountain Adventure - 5 Days ($500)");
        tourPackages.push_back("City Highlights - 2 Days ($200)");
    }

    // Function to display available packages
    void displayPackages() {
        cout << "\nAvailable Tour Packages:\n";
        for (size_t i = 0; i < tourPackages.size(); ++i) {
            cout << i + 1 << ". " << tourPackages[i] << endl;
        }
    }

    // Function to add customer details and book a package
    void addCustomer() {
        Customer customer;
        cout << "\nEnter Customer Name: ";
        cin.ignore(); // To handle leftover newlines
        getline(cin, customer.name);
        cout << "Enter Contact Number: ";
        cin >> customer.contact;

        displayPackages();
        int choice;
        cout << "Select a package (1-" << tourPackages.size() << "): ";
        cin >> choice;

        if (choice >= 1 && choice <= (int)tourPackages.size()) {
            customer.selectedPackage = tourPackages[choice - 1];
            customers.push_back(customer);
            cout << "Booking successful for " << customer.name << "!\n";
        } else {
            cout << "Invalid choice. Booking failed.\n";
        }
    }

    // Function to display all bookings
    void displayBookings() {
        if (customers.empty()) {
            cout << "\nNo bookings available.\n";
            return;
        }

        cout << "\nBooking Details:\n";
        for (size_t i = 0; i < customers.size(); ++i) {
            cout << i + 1 << ". Name: " << customers[i].name
                 << ", Contact: " << customers[i].contact
                 << ", Package: " << customers[i].selectedPackage << endl;
        }
    }
};

int main() {
    TourismManagement tm;
    int choice;

    do {
        cout << "\n=== Tourism Management System ===";
        cout << "\n1. Display Tour Packages";
        cout << "\n2. Book a Package";
        cout << "\n3. Display All Bookings";
        cout << "\n4. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            tm.displayPackages();
            break;
        case 2:
            tm.addCustomer();
            break;
        case 3:
            tm.displayBookings();
            break;
        case 4:
            cout << "Exiting... Thank you!\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}
